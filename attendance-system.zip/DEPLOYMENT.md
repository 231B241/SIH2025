# Deployment Guide

This guide covers deploying the Face Recognition Attendance System to various platforms.

## Vercel Deployment (Recommended)

### Prerequisites
- GitHub account
- Vercel account
- Repository pushed to GitHub

### Step-by-Step Deployment

1. **Prepare Your Repository**
   \`\`\`bash
   git add .
   git commit -m "Ready for deployment"
   git push origin main
   \`\`\`

2. **Connect to Vercel**
   - Visit [vercel.com](https://vercel.com)
   - Click "New Project"
   - Import your GitHub repository
   - Vercel will auto-detect the Next.js configuration

3. **Configure Environment Variables**
   In your Vercel dashboard, add these environment variables:
   \`\`\`
   PYTHON_VERSION=3.9
   DATABASE_PATH=data/attendance.db
   \`\`\`

4. **Deploy**
   - Click "Deploy"
   - Wait for build completion
   - Your app will be live at `https://your-project.vercel.app`

### Vercel Configuration

The `vercel.json` file is already configured with:
- Python 3.9 runtime for the API
- Next.js build for the frontend
- Proper routing between frontend and backend
- Increased Lambda size for OpenCV dependencies

### Post-Deployment Setup

1. **Initialize Database**
   - The database will be created automatically on first API call
   - Sample data is included for testing

2. **Test the Application**
   - Visit your deployed URL
   - Login with: admin / admin123
   - Register a test student
   - Train the model
   - Test face recognition

## Alternative Deployment Options

### Railway

1. **Connect Repository**
   - Go to [railway.app](https://railway.app)
   - Connect your GitHub repository

2. **Configure Services**
   - Create two services: Frontend (Next.js) and Backend (Python)
   - Set environment variables

3. **Deploy**
   - Railway will automatically deploy both services

### Heroku

1. **Create Heroku Apps**
   \`\`\`bash
   heroku create your-app-frontend
   heroku create your-app-backend
   \`\`\`

2. **Configure Buildpacks**
   \`\`\`bash
   # For backend
   heroku buildpacks:set heroku/python -a your-app-backend
   
   # For frontend
   heroku buildpacks:set heroku/nodejs -a your-app-frontend
   \`\`\`

3. **Deploy**
   \`\`\`bash
   git push heroku main
   \`\`\`

### Docker Deployment

1. **Create Dockerfile for Backend**
   \`\`\`dockerfile
   FROM python:3.9-slim
   
   WORKDIR /app
   
   # Install system dependencies
   RUN apt-get update && apt-get install -y \
       libgl1-mesa-glx \
       libglib2.0-0 \
       libsm6 \
       libxext6 \
       libxrender-dev \
       libgomp1 \
       && rm -rf /var/lib/apt/lists/*
   
   COPY api/requirements.txt .
   RUN pip install -r requirements.txt
   
   COPY api/ .
   COPY scripts/ ./scripts/
   
   EXPOSE 8000
   
   CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
   \`\`\`

2. **Create Dockerfile for Frontend**
   \`\`\`dockerfile
   FROM node:18-alpine
   
   WORKDIR /app
   
   COPY package*.json ./
   RUN npm ci --only=production
   
   COPY . .
   RUN npm run build
   
   EXPOSE 3000
   
   CMD ["npm", "start"]
   \`\`\`

3. **Docker Compose**
   \`\`\`yaml
   version: '3.8'
   services:
     backend:
       build:
         context: .
         dockerfile: Dockerfile.backend
       ports:
         - "8000:8000"
       volumes:
         - ./data:/app/data
         - ./training_images:/app/training_images
         - ./models:/app/models
     
     frontend:
       build:
         context: .
         dockerfile: Dockerfile.frontend
       ports:
         - "3000:3000"
       depends_on:
         - backend
   \`\`\`

## Production Considerations

### Database

For production, consider upgrading from SQLite:

1. **PostgreSQL**
   \`\`\`python
   # Update database.py
   import psycopg2
   DATABASE_URL = os.getenv('DATABASE_URL')
   \`\`\`

2. **MySQL**
   \`\`\`python
   # Update database.py
   import mysql.connector
   DATABASE_URL = os.getenv('DATABASE_URL')
   \`\`\`

### File Storage

For production file storage:

1. **AWS S3**
   \`\`\`python
   import boto3
   s3_client = boto3.client('s3')
   \`\`\`

2. **Vercel Blob**
   \`\`\`python
   from vercel_blob import put, list_blobs
   \`\`\`

### Security

1. **Environment Variables**
   \`\`\`env
   SECRET_KEY=your-secret-key
   DATABASE_URL=your-database-url
   ALLOWED_ORIGINS=https://yourdomain.com
   \`\`\`

2. **CORS Configuration**
   \`\`\`python
   app.add_middleware(
       CORSMiddleware,
       allow_origins=["https://yourdomain.com"],
       allow_credentials=True,
       allow_methods=["GET", "POST"],
       allow_headers=["*"],
   )
   \`\`\`

### Performance Optimization

1. **Image Optimization**
   - Compress uploaded images
   - Use appropriate image formats
   - Implement caching

2. **Database Optimization**
   - Add proper indexes
   - Use connection pooling
   - Implement query optimization

3. **Caching**
   - Redis for session storage
   - CDN for static assets
   - API response caching

## Monitoring and Maintenance

### Health Checks

The API includes a health check endpoint:
\`\`\`
GET /api/health
\`\`\`

### Logging

Configure logging for production:
\`\`\`python
import logging
logging.basicConfig(level=logging.INFO)
\`\`\`

### Backup Strategy

1. **Database Backups**
   - Automated daily backups
   - Point-in-time recovery

2. **File Backups**
   - Training images backup
   - Model files backup

### Updates and Maintenance

1. **Dependency Updates**
   \`\`\`bash
   npm audit fix
   pip list --outdated
   \`\`\`

2. **Security Updates**
   - Regular dependency updates
   - Security scanning
   - Vulnerability assessments

## Troubleshooting Deployment

### Common Issues

1. **Build Failures**
   - Check dependency versions
   - Verify Python/Node versions
   - Review build logs

2. **Runtime Errors**
   - Check environment variables
   - Verify file permissions
   - Review application logs

3. **Performance Issues**
   - Monitor resource usage
   - Optimize database queries
   - Implement caching

### Getting Help

- Check deployment platform documentation
- Review application logs
- Test locally first
- Use staging environment

This deployment guide should help you successfully deploy your Face Recognition Attendance System to production.
