from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import cv2
import numpy as np
import os
import datetime
import time
import pandas as pd
from PIL import Image
import io
import base64
from typing import List, Optional
import json

from .config import settings, get_cors_origins, logger
from .database import DatabaseManager, get_db_connection

app = FastAPI(
    title="Face Recognition Attendance System", 
    version="1.0.0",
    description="A modern attendance management system using face recognition technology"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=get_cors_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

os.makedirs(settings.upload_dir, exist_ok=True)
os.makedirs(settings.model_dir, exist_ok=True)
os.makedirs(settings.data_dir, exist_ok=True)

@app.on_startup
async def startup_event():
    """Application startup event"""
    logger.info("Starting Face Recognition Attendance System")
    logger.info(f"Database path: {settings.database_path}")
    logger.info(f"Upload directory: {settings.upload_dir}")
    logger.info(f"Model directory: {settings.model_dir}")

@app.on_shutdown
async def shutdown_event():
    """Application shutdown event"""
    logger.info("Shutting down Face Recognition Attendance System")

@app.get("/")
async def root():
    return {
        "message": "Face Recognition Attendance System API", 
        "version": "1.0.0",
        "status": "running"
    }

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.datetime.now().isoformat(),
        "database": "connected",
        "version": "1.0.0"
    }

@app.get("/api/config")
async def get_config():
    """Get public configuration"""
    return {
        "recognition_threshold": settings.recognition_threshold,
        "max_training_images": settings.max_training_images,
        "image_quality_threshold": settings.image_quality_threshold,
        "version": "1.0.0"
    }

@app.post("/api/register-student")
async def register_student(
    enrollment: str = Form(...),
    name: str = Form(...),
    email: str = Form(None),
    phone: str = Form(None),
    images: List[UploadFile] = File(...)
):
    """Register a new student with face images"""
    try:
        logger.info(f"Registering student: {name} ({enrollment})")
        
        # Validate image count
        if len(images) > settings.max_training_images:
            raise HTTPException(
                status_code=400, 
                detail=f"Too many images. Maximum allowed: {settings.max_training_images}"
            )
        
        success = DatabaseManager.create_student(enrollment, name, email, phone)
        if not success:
            raise HTTPException(status_code=400, detail="Student with this enrollment already exists")
        
        student_dir = f"{settings.upload_dir}/{name}_{enrollment}"
        os.makedirs(student_dir, exist_ok=True)
        
        saved_images = []
        for i, image in enumerate(images):
            if image.content_type.startswith('image/'):
                contents = await image.read()
                image_path = f"{student_dir}/{name}.{enrollment}.{i+1}.jpg"
                
                # Convert to OpenCV format and save
                nparr = np.frombuffer(contents, np.uint8)
                img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                cv2.imwrite(image_path, img)
                saved_images.append(image_path)
        
        logger.info(f"Student {name} registered with {len(saved_images)} images")
        
        return {
            "message": f"Student {name} registered successfully",
            "enrollment": enrollment,
            "images_saved": len(saved_images)
        }
        
    except Exception as e:
        logger.error(f"Error registering student: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/train-model")
async def train_model():
    """Train the face recognition model"""
    try:
        logger.info("Starting model training")
        
        recognizer = cv2.face.LBPHFaceRecognizer_create()
        detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        
        faces = []
        ids = []
        
        for root, dirs, files in os.walk(settings.upload_dir):
            for file in files:
                if file.endswith('.jpg'):
                    path = os.path.join(root, file)
                    enrollment = int(file.split('.')[1])
                    
                    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
                    detected_faces = detector.detectMultiScale(img, 1.3, 5)
                    
                    for (x, y, w, h) in detected_faces:
                        faces.append(img[y:y+h, x:x+w])
                        ids.append(enrollment)
        
        if len(faces) == 0:
            raise HTTPException(status_code=400, detail="No training images found")
        
        # Train the model
        recognizer.train(faces, np.array(ids))
        
        model_path = f"{settings.model_dir}/trainer.yml"
        recognizer.save(model_path)
        
        unique_students = len(set(ids))
        DatabaseManager.log_model_training(len(faces), unique_students)
        
        logger.info(f"Model trained with {len(faces)} faces from {unique_students} students")
        
        return {
            "message": "Model trained successfully",
            "faces_trained": len(faces),
            "unique_students": unique_students,
            "model_path": model_path
        }
        
    except Exception as e:
        logger.error(f"Error training model: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/mark-attendance")
async def mark_attendance(
    subject: str = Form(...),
    image: UploadFile = File(...)
):
    """Mark attendance using face recognition"""
    try:
        logger.info(f"Marking attendance for subject: {subject}")
        
        model_path = f"{settings.model_dir}/trainer.yml"
        if not os.path.exists(model_path):
            raise HTTPException(status_code=400, detail="Model not trained. Please train the model first.")
        
        recognizer = cv2.face.LBPHFaceRecognizer_create()
        recognizer.read(model_path)
        detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        
        # Process uploaded image
        contents = await image.read()
        nparr = np.frombuffer(contents, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        faces = detector.detectMultiScale(gray, 1.2, 5)
        
        recognized_students = []
        
        for (x, y, w, h) in faces:
            face_id, confidence = recognizer.predict(gray[y:y+h, x:x+w])
            
            if confidence < settings.recognition_threshold:
                student = DatabaseManager.get_student(str(face_id))
                
                if student:
                    current_time = datetime.datetime.now()
                    date = current_time.strftime('%Y-%m-%d')
                    time_str = current_time.strftime('%H:%M:%S')
                    
                    success = DatabaseManager.mark_attendance(
                        str(face_id), student['name'], subject, date, time_str,
                        'automatic', float(100 - confidence)
                    )
                    
                    if success:
                        recognized_students.append({
                            "enrollment": str(face_id),
                            "name": student['name'],
                            "confidence": float(100 - confidence)
                        })
                        logger.info(f"Attendance marked for {student['name']} ({face_id})")
        
        return {
            "message": "Attendance marked successfully",
            "subject": subject,
            "recognized_students": recognized_students,
            "total_faces": len(faces)
        }
        
    except Exception as e:
        logger.error(f"Error marking attendance: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/attendance/{subject}")
async def get_attendance(subject: str, date: Optional[str] = None):
    """Get attendance records for a subject"""
    try:
        records = DatabaseManager.get_attendance(subject, date)
        
        return {
            "subject": subject,
            "date": date,
            "attendance": records,
            "total_present": len(records)
        }
        
    except Exception as e:
        logger.error(f"Error getting attendance: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/students")
async def get_students():
    """Get all registered students"""
    try:
        students = DatabaseManager.get_all_students()
        
        return {"students": students}
        
    except Exception as e:
        logger.error(f"Error getting students: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/manual-attendance")
async def manual_attendance(
    enrollment: str = Form(...),
    name: str = Form(...),
    subject: str = Form(...)
):
    """Manually mark attendance"""
    try:
        logger.info(f"Manual attendance for {name} ({enrollment}) in {subject}")
        
        current_time = datetime.datetime.now()
        date = current_time.strftime('%Y-%m-%d')
        time_str = current_time.strftime('%H:%M:%S')
        
        success = DatabaseManager.mark_attendance(
            enrollment, name, subject, date, time_str, 'manual', 100.0
        )
        
        if not success:
            raise HTTPException(status_code=400, detail="Attendance already marked for today")
        
        return {
            "message": "Manual attendance marked successfully",
            "enrollment": enrollment,
            "name": name,
            "subject": subject,
            "date": date,
            "time": time_str
        }
        
    except Exception as e:
        logger.error(f"Error marking manual attendance: {e}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app, 
        host=settings.api_host, 
        port=settings.api_port, 
        reload=settings.api_reload
    )
