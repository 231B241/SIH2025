"""
Configuration management for the Face Recognition Attendance System
"""

import os
from typing import List, Optional
from pydantic import BaseSettings, validator

class Settings(BaseSettings):
    """Application settings with environment variable support"""
    
    # API Configuration
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    api_reload: bool = False
    
    # Database Configuration
    database_path: str = "data/attendance.db"
    database_url: str = "sqlite:///data/attendance.db"
    
    # Security
    secret_key: str = "your-secret-key-change-in-production"
    allowed_origins: List[str] = ["http://localhost:3000", "https://localhost:3000"]
    
    # File Storage
    upload_dir: str = "training_images"
    model_dir: str = "models"
    data_dir: str = "data"
    
    # Face Recognition Settings
    recognition_threshold: float = 70.0
    max_training_images: int = 100
    image_quality_threshold: float = 0.8
    
    # Logging
    log_level: str = "INFO"
    log_file: Optional[str] = None
    
    # Production Settings
    python_version: str = "3.9"
    node_env: str = "development"
    
    # Optional: External Database
    postgres_url: Optional[str] = None
    mysql_url: Optional[str] = None
    
    # Optional: Cloud Storage
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_s3_bucket: Optional[str] = None
    aws_region: str = "us-east-1"
    
    # Optional: Email Notifications
    smtp_host: Optional[str] = None
    smtp_port: int = 587
    smtp_user: Optional[str] = None
    smtp_password: Optional[str] = None
    
    # Optional: Monitoring
    sentry_dsn: Optional[str] = None
    analytics_id: Optional[str] = None
    
    @validator('allowed_origins', pre=True)
    def parse_origins(cls, v):
        """Parse comma-separated origins string"""
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(',')]
        return v
    
    @validator('database_path')
    def ensure_database_dir(cls, v):
        """Ensure database directory exists"""
        os.makedirs(os.path.dirname(v), exist_ok=True)
        return v
    
    @validator('upload_dir', 'model_dir', 'data_dir')
    def ensure_directories(cls, v):
        """Ensure required directories exist"""
        os.makedirs(v, exist_ok=True)
        return v
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False

# Global settings instance
settings = Settings()

def get_settings() -> Settings:
    """Get application settings"""
    return settings

# Database URL based on environment
def get_database_url() -> str:
    """Get the appropriate database URL"""
    if settings.postgres_url:
        return settings.postgres_url
    elif settings.mysql_url:
        return settings.mysql_url
    else:
        return f"sqlite:///{settings.database_path}"

# CORS origins for FastAPI
def get_cors_origins() -> List[str]:
    """Get CORS origins for the API"""
    origins = settings.allowed_origins.copy()
    
    # Add common development origins
    if settings.node_env == "development":
        dev_origins = [
            "http://localhost:3000",
            "http://127.0.0.1:3000",
            "https://localhost:3000",
            "https://127.0.0.1:3000"
        ]
        origins.extend([origin for origin in dev_origins if origin not in origins])
    
    return origins

# Logging configuration
def setup_logging():
    """Setup application logging"""
    import logging
    
    # Set log level
    log_level = getattr(logging, settings.log_level.upper(), logging.INFO)
    
    # Configure logging
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            *([logging.FileHandler(settings.log_file)] if settings.log_file else [])
        ]
    )
    
    return logging.getLogger(__name__)

# Initialize logging
logger = setup_logging()
