"""
Database utilities and connection management for the attendance system
"""

import sqlite3
import os
from contextlib import contextmanager
from typing import List, Dict, Any, Optional
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database configuration
DATABASE_PATH = os.getenv('DATABASE_PATH', 'data/attendance.db')

def ensure_database_exists():
    """Ensure database and directory exist"""
    os.makedirs(os.path.dirname(DATABASE_PATH), exist_ok=True)
    
    if not os.path.exists(DATABASE_PATH):
        logger.info("Database not found, creating new database...")
        init_database()

@contextmanager
def get_db_connection():
    """Context manager for database connections"""
    conn = None
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        conn.row_factory = sqlite3.Row  # Enable column access by name
        yield conn
    except Exception as e:
        if conn:
            conn.rollback()
        logger.error(f"Database error: {e}")
        raise
    finally:
        if conn:
            conn.close()

def init_database():
    """Initialize database with required tables"""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Create students table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                enrollment VARCHAR(100) UNIQUE NOT NULL,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100),
                phone VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create attendance table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                enrollment VARCHAR(100) NOT NULL,
                name VARCHAR(100) NOT NULL,
                subject VARCHAR(100) NOT NULL,
                date VARCHAR(20) NOT NULL,
                time VARCHAR(20) NOT NULL,
                attendance_type VARCHAR(20) DEFAULT 'automatic',
                confidence_score REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (enrollment) REFERENCES students(enrollment)
            )
        ''')
        
        # Create subjects table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS subjects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subject_code VARCHAR(20) UNIQUE NOT NULL,
                subject_name VARCHAR(100) NOT NULL,
                instructor VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create model_training_log table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS model_training_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                training_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                faces_trained INTEGER NOT NULL,
                unique_students INTEGER NOT NULL,
                model_accuracy REAL,
                status VARCHAR(20) DEFAULT 'completed'
            )
        ''')
        
        # Create indexes
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_subject ON attendance(subject)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_enrollment ON attendance(enrollment)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_students_enrollment ON students(enrollment)')
        
        conn.commit()
        logger.info("Database initialized successfully")

class DatabaseManager:
    """Database operations manager"""
    
    @staticmethod
    def create_student(enrollment: str, name: str, email: str = None, phone: str = None) -> bool:
        """Create a new student record"""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT INTO students (enrollment, name, email, phone) VALUES (?, ?, ?, ?)",
                    (enrollment, name, email, phone)
                )
                conn.commit()
                return True
        except sqlite3.IntegrityError:
            logger.warning(f"Student with enrollment {enrollment} already exists")
            return False
        except Exception as e:
            logger.error(f"Error creating student: {e}")
            return False
    
    @staticmethod
    def get_student(enrollment: str) -> Optional[Dict[str, Any]]:
        """Get student by enrollment number"""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM students WHERE enrollment = ?", (enrollment,))
                row = cursor.fetchone()
                return dict(row) if row else None
        except Exception as e:
            logger.error(f"Error getting student: {e}")
            return None
    
    @staticmethod
    def get_all_students() -> List[Dict[str, Any]]:
        """Get all students"""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM students ORDER BY name")
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting students: {e}")
            return []
    
    @staticmethod
    def mark_attendance(enrollment: str, name: str, subject: str, date: str, time: str, 
                       attendance_type: str = 'automatic', confidence_score: float = 0.0) -> bool:
        """Mark attendance for a student"""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                
                # Check if already marked today
                cursor.execute(
                    "SELECT id FROM attendance WHERE enrollment = ? AND subject = ? AND date = ?",
                    (enrollment, subject, date)
                )
                
                if cursor.fetchone():
                    logger.warning(f"Attendance already marked for {enrollment} in {subject} on {date}")
                    return False
                
                cursor.execute(
                    """INSERT INTO attendance 
                       (enrollment, name, subject, date, time, attendance_type, confidence_score) 
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (enrollment, name, subject, date, time, attendance_type, confidence_score)
                )
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Error marking attendance: {e}")
            return False
    
    @staticmethod
    def get_attendance(subject: str, date: str = None) -> List[Dict[str, Any]]:
        """Get attendance records"""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                
                if date:
                    cursor.execute(
                        "SELECT * FROM attendance WHERE subject = ? AND date = ? ORDER BY time",
                        (subject, date)
                    )
                else:
                    cursor.execute(
                        "SELECT * FROM attendance WHERE subject = ? ORDER BY date DESC, time DESC",
                        (subject,)
                    )
                
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Error getting attendance: {e}")
            return []
    
    @staticmethod
    def log_model_training(faces_trained: int, unique_students: int, model_accuracy: float = None) -> bool:
        """Log model training information"""
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT INTO model_training_log (faces_trained, unique_students, model_accuracy) VALUES (?, ?, ?)",
                    (faces_trained, unique_students, model_accuracy)
                )
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Error logging model training: {e}")
            return False

# Initialize database on module import
ensure_database_exists()
