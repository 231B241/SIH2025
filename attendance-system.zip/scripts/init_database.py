#!/usr/bin/env python3
"""
Database initialization script for Face Recognition Attendance System
Creates necessary tables and sets up the database structure
"""

import sqlite3
import os
from datetime import datetime

def create_database():
    """Create the SQLite database and tables"""
    
    # Ensure the database directory exists
    os.makedirs('data', exist_ok=True)
    
    # Connect to database (creates if doesn't exist)
    conn = sqlite3.connect('data/attendance.db')
    cursor = conn.cursor()
    
    print("Creating database tables...")
    
    # Create students table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            enrollment VARCHAR(100) UNIQUE NOT NULL,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100),
            phone VARCHAR(20),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create attendance table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            enrollment VARCHAR(100) NOT NULL,
            name VARCHAR(100) NOT NULL,
            subject VARCHAR(100) NOT NULL,
            date VARCHAR(20) NOT NULL,
            time VARCHAR(20) NOT NULL,
            attendance_type VARCHAR(20) DEFAULT 'automatic',
            confidence_score REAL DEFAULT 0.0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (enrollment) REFERENCES students(enrollment)
        )
    ''')
    
    # Create subjects table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject_code VARCHAR(20) UNIQUE NOT NULL,
            subject_name VARCHAR(100) NOT NULL,
            instructor VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create model_training_log table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS model_training_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            training_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            faces_trained INTEGER NOT NULL,
            unique_students INTEGER NOT NULL,
            model_accuracy REAL,
            status VARCHAR(20) DEFAULT 'completed'
        )
    ''')
    
    # Create indexes for better performance
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_subject ON attendance(subject)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_enrollment ON attendance(enrollment)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_students_enrollment ON students(enrollment)')
    
    # Insert sample data
    print("Inserting sample data...")
    
    # Sample subjects
    sample_subjects = [
        ('CS101', 'Computer Science Fundamentals', 'Dr. Smith'),
        ('MATH201', 'Advanced Mathematics', 'Prof. Johnson'),
        ('PHY101', 'Physics Basics', 'Dr. Brown'),
        ('ENG101', 'English Literature', 'Prof. Davis')
    ]
    
    cursor.executemany('''
        INSERT OR IGNORE INTO subjects (subject_code, subject_name, instructor)
        VALUES (?, ?, ?)
    ''', sample_subjects)
    
    # Sample students (for testing)
    sample_students = [
        ('2024001', 'John Doe', 'john.doe@example.com', '+1234567890'),
        ('2024002', 'Jane Smith', 'jane.smith@example.com', '+1234567891'),
        ('2024003', 'Bob Johnson', 'bob.johnson@example.com', '+1234567892')
    ]
    
    cursor.executemany('''
        INSERT OR IGNORE INTO students (enrollment, name, email, phone)
        VALUES (?, ?, ?, ?)
    ''', sample_students)
    
    conn.commit()
    conn.close()
    
    print("Database initialized successfully!")
    print("Database location: data/attendance.db")
    print("Sample data inserted for testing")

def verify_database():
    """Verify database structure and show table information"""
    
    if not os.path.exists('data/attendance.db'):
        print("Database not found. Please run create_database() first.")
        return
    
    conn = sqlite3.connect('data/attendance.db')
    cursor = conn.cursor()
    
    # Get table information
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cursor.fetchall()
    
    print("\nDatabase Tables:")
    print("-" * 40)
    
    for table in tables:
        table_name = table[0]
        print(f"\nTable: {table_name}")
        
        # Get column information
        cursor.execute(f"PRAGMA table_info({table_name})")
        columns = cursor.fetchall()
        
        for col in columns:
            print(f"  - {col[1]} ({col[2]})")
        
        # Get row count
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        count = cursor.fetchone()[0]
        print(f"  Rows: {count}")
    
    conn.close()

if __name__ == "__main__":
    print("Face Recognition Attendance System - Database Setup")
    print("=" * 50)
    
    create_database()
    verify_database()
    
    print("\nSetup complete! You can now run the application.")
