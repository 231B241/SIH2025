# Face Recognition Attendance Management System

A modern web-based attendance management system using face recognition technology, built with Next.js frontend and FastAPI backend.

## Features

- **Face Recognition**: Automatic attendance marking using OpenCV and machine learning
- **Student Management**: Register students with multiple face images
- **Manual Attendance**: Fallback option for manual attendance marking
- **Real-time Dashboard**: Modern glassmorphism UI with real-time statistics
- **Attendance Reports**: View and export attendance records by subject and date
- **Model Training**: Train face recognition models with registered student data

## Tech Stack

### Frontend
- **Next.js 14** - React framework with App Router
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Modern styling with glassmorphism effects
- **Shadcn/ui** - Beautiful UI components
- **Lucide React** - Modern icons

### Backend
- **FastAPI** - High-performance Python web framework
- **OpenCV** - Computer vision and face recognition
- **SQLite** - Lightweight database for development
- **Pillow** - Image processing
- **NumPy** - Numerical computations

## Quick Start

### Prerequisites

- Node.js 18+ and npm
- Python 3.9+
- Git

### Installation

1. **Clone the repository**
   \`\`\`bash
   git clone <your-repo-url>
   cd face-recognition-attendance-system
   \`\`\`

2. **Install frontend dependencies**
   \`\`\`bash
   npm install
   \`\`\`

3. **Install backend dependencies**
   \`\`\`bash
   pip install -r api/requirements.txt
   \`\`\`

4. **Initialize the database**
   \`\`\`bash
   python scripts/init_database.py
   \`\`\`

### Local Development

1. **Start the backend server**
   \`\`\`bash
   cd api
   uvicorn main:app --reload --port 8000
   \`\`\`

2. **Start the frontend development server**
   \`\`\`bash
   npm run dev
   \`\`\`

3. **Access the application**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000
   - API Documentation: http://localhost:8000/docs

### Default Login Credentials

- **Username**: admin
- **Password**: admin123

## Deployment to Vercel

### Automatic Deployment

1. **Push to GitHub**
   \`\`\`bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   \`\`\`

2. **Connect to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Import your GitHub repository
   - Vercel will automatically detect the configuration

### Manual Deployment

1. **Install Vercel CLI**
   \`\`\`bash
   npm i -g vercel
   \`\`\`

2. **Deploy**
   \`\`\`bash
   vercel --prod
   \`\`\`

### Environment Variables

Set these environment variables in your Vercel dashboard:

\`\`\`env
# Database (optional - uses SQLite by default)
DATABASE_PATH=data/attendance.db

# Python Runtime
PYTHON_VERSION=3.9
\`\`\`

## Project Structure

\`\`\`
├── api/                    # FastAPI backend
│   ├── main.py            # Main API application
│   ├── database.py        # Database utilities
│   └── requirements.txt   # Python dependencies
├── app/                   # Next.js frontend
│   ├── page.tsx          # Main application page
│   └── layout.tsx        # Root layout
├── components/           # React components
│   ├── login-form.tsx   # Authentication form
│   ├── dashboard.tsx    # Main dashboard
│   ├── student-registration.tsx
│   ├── attendance-marking.tsx
│   ├── attendance-records.tsx
│   └── student-list.tsx
├── scripts/             # Utility scripts
│   └── init_database.py # Database initialization
├── public/             # Static assets
├── vercel.json        # Vercel deployment config
└── README.md         # This file
\`\`\`

## API Endpoints

### Authentication
- `GET /` - API status
- `GET /api/health` - Health check

### Student Management
- `POST /api/register-student` - Register new student with images
- `GET /api/students` - Get all registered students

### Attendance
- `POST /api/mark-attendance` - Mark attendance using face recognition
- `POST /api/manual-attendance` - Manually mark attendance
- `GET /api/attendance/{subject}` - Get attendance records

### Model Training
- `POST /api/train-model` - Train face recognition model

## Usage Guide

### 1. Register Students

1. Navigate to the "Register" tab
2. Fill in student details (enrollment number, name)
3. Upload multiple clear face images (recommended: 5-10 images)
4. Click "Register Student"

### 2. Train the Model

1. After registering students, go to "Register" tab
2. Click "Train Model" to process all student images
3. Wait for training completion

### 3. Mark Attendance

1. Go to "Mark Attendance" tab
2. Enter subject name
3. Upload an image containing student faces
4. The system will automatically recognize and mark attendance

### 4. View Records

1. Navigate to "Records" tab
2. Enter subject name and optional date
3. View attendance statistics and export data

## Troubleshooting

### Common Issues

1. **Model not trained error**
   - Ensure you have registered students with images
   - Run the model training process

2. **Face not recognized**
   - Ensure good lighting in images
   - Use clear, front-facing photos
   - Train model with more diverse images

3. **Database errors**
   - Run the database initialization script
   - Check file permissions

### Development Issues

1. **CORS errors**
   - Ensure backend is running on port 8000
   - Check CORS configuration in main.py

2. **Import errors**
   - Verify all dependencies are installed
   - Check Python version compatibility

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:
- Create an issue on GitHub
- Check the troubleshooting section
- Review the API documentation at `/docs`

## Acknowledgments

- OpenCV community for computer vision tools
- FastAPI for the excellent web framework
- Next.js team for the React framework
- Vercel for hosting and deployment platform
