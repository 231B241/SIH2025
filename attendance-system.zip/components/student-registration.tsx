"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Camera, Upload, User, Hash, Brain } from "lucide-react"

export function StudentRegistration() {
  const [enrollment, setEnrollment] = useState("")
  const [name, setName] = useState("")
  const [images, setImages] = useState<File[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState("")

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setImages(Array.from(e.target.files))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setMessage("")

    try {
      const formData = new FormData()
      formData.append("enrollment", enrollment)
      formData.append("name", name)

      images.forEach((image, index) => {
        formData.append("images", image)
      })

      const response = await fetch("/api/register-student", {
        method: "POST",
        body: formData,
      })

      const result = await response.json()

      if (response.ok) {
        setMessage(`Student ${name} registered successfully with ${result.images_saved} images!`)
        setEnrollment("")
        setName("")
        setImages([])
      } else {
        setMessage(`Error: ${result.detail}`)
      }
    } catch (error) {
      setMessage("Error connecting to server")
    } finally {
      setIsLoading(false)
    }
  }

  const handleTrainModel = async () => {
    setIsLoading(true)
    setMessage("")

    try {
      const response = await fetch("/api/train-model", {
        method: "POST",
      })

      const result = await response.json()

      if (response.ok) {
        setMessage(
          `Model trained successfully! Processed ${result.faces_trained} faces from ${result.unique_students} students.`,
        )
      } else {
        setMessage(`Error: ${result.detail}`)
      }
    } catch (error) {
      setMessage("Error connecting to server")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card className="bg-black/30 backdrop-blur-xl border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <User className="h-5 w-5 mr-2" />
            Register New Student
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="enrollment" className="text-white/70">
                  Enrollment Number
                </Label>
                <div className="relative">
                  <Input
                    id="enrollment"
                    type="text"
                    placeholder="Enter enrollment number"
                    value={enrollment}
                    onChange={(e) => setEnrollment(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 pl-10"
                    required
                  />
                  <Hash className="absolute left-3 top-3 h-4 w-4 text-white/50" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="name" className="text-white/70">
                  Student Name
                </Label>
                <div className="relative">
                  <Input
                    id="name"
                    type="text"
                    placeholder="Enter student name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 pl-10"
                    required
                  />
                  <User className="absolute left-3 top-3 h-4 w-4 text-white/50" />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="images" className="text-white/70">
                Face Images (Multiple images recommended)
              </Label>
              <div className="relative">
                <Input
                  id="images"
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="bg-white/10 border-white/20 text-white file:bg-white/20 file:text-white file:border-0 file:rounded-md file:mr-4 file:py-2 file:px-4"
                  required
                />
                <Upload className="absolute right-3 top-3 h-4 w-4 text-white/50" />
              </div>
              {images.length > 0 && <p className="text-white/70 text-sm">{images.length} image(s) selected</p>}
            </div>

            <Button type="submit" disabled={isLoading} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              <Camera className="h-4 w-4 mr-2" />
              {isLoading ? "Registering..." : "Register Student"}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="bg-black/30 backdrop-blur-xl border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Brain className="h-5 w-5 mr-2" />
            Train Recognition Model
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-white/70 mb-4">
            After registering students, train the model to enable face recognition for attendance marking.
          </p>
          <Button
            onClick={handleTrainModel}
            disabled={isLoading}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            <Brain className="h-4 w-4 mr-2" />
            {isLoading ? "Training..." : "Train Model"}
          </Button>
        </CardContent>
      </Card>

      {message && (
        <Card className="bg-black/30 backdrop-blur-xl border-white/20">
          <CardContent className="pt-6">
            <p className={`text-center ${message.includes("Error") ? "text-red-400" : "text-green-400"}`}>{message}</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
