"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Camera, Upload, BookOpen, Users } from "lucide-react"

export function AttendanceMarking() {
  const [subject, setSubject] = useState("")
  const [image, setImage] = useState<File | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImage(e.target.files[0])
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!image) return

    setIsLoading(true)
    setResult(null)

    try {
      const formData = new FormData()
      formData.append("subject", subject)
      formData.append("image", image)

      const response = await fetch("/api/mark-attendance", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()
      setResult(data)
    } catch (error) {
      setResult({ error: "Error connecting to server" })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card className="bg-black/30 backdrop-blur-xl border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Camera className="h-5 w-5 mr-2" />
            Mark Attendance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="subject" className="text-white/70">
                Subject Name
              </Label>
              <div className="relative">
                <Input
                  id="subject"
                  type="text"
                  placeholder="Enter subject name"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50 pl-10"
                  required
                />
                <BookOpen className="absolute left-3 top-3 h-4 w-4 text-white/50" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="attendance-image" className="text-white/70">
                Upload Image for Recognition
              </Label>
              <div className="relative">
                <Input
                  id="attendance-image"
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="bg-white/10 border-white/20 text-white file:bg-white/20 file:text-white file:border-0 file:rounded-md file:mr-4 file:py-2 file:px-4"
                  required
                />
                <Upload className="absolute right-3 top-3 h-4 w-4 text-white/50" />
              </div>
            </div>

            <Button
              type="submit"
              disabled={isLoading || !image}
              className="w-full bg-green-600 hover:bg-green-700 text-white"
            >
              <Camera className="h-4 w-4 mr-2" />
              {isLoading ? "Processing..." : "Mark Attendance"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {result && (
        <Card className="bg-black/30 backdrop-blur-xl border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Users className="h-5 w-5 mr-2" />
              Recognition Results
            </CardTitle>
          </CardHeader>
          <CardContent>
            {result.error ? (
              <p className="text-red-400">{result.error}</p>
            ) : (
              <div className="space-y-4">
                <div className="text-white">
                  <p>
                    <strong>Subject:</strong> {result.subject}
                  </p>
                  <p>
                    <strong>Total Faces Detected:</strong> {result.total_faces}
                  </p>
                  <p>
                    <strong>Students Recognized:</strong> {result.recognized_students?.length || 0}
                  </p>
                </div>

                {result.recognized_students && result.recognized_students.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-white font-semibold">Attendance Marked For:</h4>
                    {result.recognized_students.map((student: any, index: number) => (
                      <div key={index} className="bg-white/10 p-3 rounded-lg">
                        <p className="text-white">
                          <strong>{student.name}</strong> (ID: {student.enrollment})
                        </p>
                        <p className="text-white/70 text-sm">Confidence: {student.confidence.toFixed(1)}%</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
