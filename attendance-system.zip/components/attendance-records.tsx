"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Calendar, BookOpen } from "lucide-react"

export function AttendanceRecords() {
  const [subject, setSubject] = useState("")
  const [date, setDate] = useState("")
  const [records, setRecords] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const fetchRecords = async () => {
    if (!subject) return

    setIsLoading(true)
    try {
      const url = date ? `/api/attendance/${subject}?date=${date}` : `/api/attendance/${subject}`

      const response = await fetch(url)
      const data = await response.json()
      setRecords(data.attendance || [])
    } catch (error) {
      console.error("Error fetching records:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card className="bg-black/30 backdrop-blur-xl border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Search className="h-5 w-5 mr-2" />
            Search Attendance Records
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="space-y-2">
              <Label htmlFor="search-subject" className="text-white/70">
                Subject Name
              </Label>
              <div className="relative">
                <Input
                  id="search-subject"
                  type="text"
                  placeholder="Enter subject name"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50 pl-10"
                />
                <BookOpen className="absolute left-3 top-3 h-4 w-4 text-white/50" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="search-date" className="text-white/70">
                Date (Optional)
              </Label>
              <div className="relative">
                <Input
                  id="search-date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="bg-white/10 border-white/20 text-white pl-10"
                />
                <Calendar className="absolute left-3 top-3 h-4 w-4 text-white/50" />
              </div>
            </div>

            <div className="flex items-end">
              <Button
                onClick={fetchRecords}
                disabled={isLoading || !subject}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Search className="h-4 w-4 mr-2" />
                {isLoading ? "Searching..." : "Search"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {records.length > 0 && (
        <Card className="bg-black/30 backdrop-blur-xl border-white/20">
          <CardHeader>
            <CardTitle className="text-white">Attendance Records ({records.length} entries)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/20">
                    <TableHead className="text-white/70">Enrollment</TableHead>
                    <TableHead className="text-white/70">Name</TableHead>
                    <TableHead className="text-white/70">Subject</TableHead>
                    <TableHead className="text-white/70">Date</TableHead>
                    <TableHead className="text-white/70">Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {records.map((record, index) => (
                    <TableRow key={index} className="border-white/10">
                      <TableCell className="text-white">{record.enrollment}</TableCell>
                      <TableCell className="text-white">{record.name}</TableCell>
                      <TableCell className="text-white">{record.subject}</TableCell>
                      <TableCell className="text-white">{record.date}</TableCell>
                      <TableCell className="text-white">{record.time}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
