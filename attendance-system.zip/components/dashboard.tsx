"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, Camera, BookOpen, ClipboardList, LogOut, UserPlus, Brain, Calendar } from "lucide-react"
import { StudentRegistration } from "@/components/student-registration"
import { AttendanceMarking } from "@/components/attendance-marking"
import { AttendanceRecords } from "@/components/attendance-records"
import { StudentList } from "@/components/student-list"

interface DashboardProps {
  user: { username: string } | null
  onLogout: () => void
}

export function Dashboard({ user, onLogout }: DashboardProps) {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-xl border-b border-white/10">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-white">Face Recognition Attendance System</h1>
            <p className="text-white/70">Welcome, {user?.username}</p>
          </div>
          <Button
            onClick={onLogout}
            variant="outline"
            className="bg-white/10 border-white/20 text-white hover:bg-white/20"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 bg-black/20 backdrop-blur-xl border border-white/10">
            <TabsTrigger value="overview" className="text-white data-[state=active]:bg-white/20">
              <BookOpen className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="register" className="text-white data-[state=active]:bg-white/20">
              <UserPlus className="h-4 w-4 mr-2" />
              Register
            </TabsTrigger>
            <TabsTrigger value="attendance" className="text-white data-[state=active]:bg-white/20">
              <Camera className="h-4 w-4 mr-2" />
              Mark Attendance
            </TabsTrigger>
            <TabsTrigger value="records" className="text-white data-[state=active]:bg-white/20">
              <ClipboardList className="h-4 w-4 mr-2" />
              Records
            </TabsTrigger>
            <TabsTrigger value="students" className="text-white data-[state=active]:bg-white/20">
              <Users className="h-4 w-4 mr-2" />
              Students
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-black/30 backdrop-blur-xl border-white/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white/70">Total Students</CardTitle>
                  <Users className="h-4 w-4 text-blue-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">0</div>
                </CardContent>
              </Card>

              <Card className="bg-black/30 backdrop-blur-xl border-white/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white/70">Today's Attendance</CardTitle>
                  <Calendar className="h-4 w-4 text-green-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">0</div>
                </CardContent>
              </Card>

              <Card className="bg-black/30 backdrop-blur-xl border-white/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white/70">Model Status</CardTitle>
                  <Brain className="h-4 w-4 text-purple-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">Not Trained</div>
                </CardContent>
              </Card>

              <Card className="bg-black/30 backdrop-blur-xl border-white/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white/70">Active Sessions</CardTitle>
                  <Camera className="h-4 w-4 text-orange-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">0</div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/30 backdrop-blur-xl border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button
                  onClick={() => setActiveTab("register")}
                  className="bg-blue-600 hover:bg-blue-700 text-white h-20 flex flex-col items-center justify-center"
                >
                  <UserPlus className="h-6 w-6 mb-2" />
                  Register Student
                </Button>
                <Button
                  onClick={() => setActiveTab("attendance")}
                  className="bg-green-600 hover:bg-green-700 text-white h-20 flex flex-col items-center justify-center"
                >
                  <Camera className="h-6 w-6 mb-2" />
                  Mark Attendance
                </Button>
                <Button
                  onClick={() => setActiveTab("records")}
                  className="bg-purple-600 hover:bg-purple-700 text-white h-20 flex flex-col items-center justify-center"
                >
                  <ClipboardList className="h-6 w-6 mb-2" />
                  View Records
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="register">
            <StudentRegistration />
          </TabsContent>

          <TabsContent value="attendance">
            <AttendanceMarking />
          </TabsContent>

          <TabsContent value="records">
            <AttendanceRecords />
          </TabsContent>

          <TabsContent value="students">
            <StudentList />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
