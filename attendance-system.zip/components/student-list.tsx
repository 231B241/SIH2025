"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Users, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"

export function StudentList() {
  const [students, setStudents] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const fetchStudents = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/students")
      const data = await response.json()
      setStudents(data.students || [])
    } catch (error) {
      console.error("Error fetching students:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchStudents()
  }, [])

  return (
    <div className="space-y-6">
      <Card className="bg-black/30 backdrop-blur-xl border-white/20">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-white flex items-center">
            <Users className="h-5 w-5 mr-2" />
            Registered Students ({students.length})
          </CardTitle>
          <Button
            onClick={fetchStudents}
            disabled={isLoading}
            variant="outline"
            className="bg-white/10 border-white/20 text-white hover:bg-white/20"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </CardHeader>
        <CardContent>
          {students.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/20">
                    <TableHead className="text-white/70">ID</TableHead>
                    <TableHead className="text-white/70">Enrollment</TableHead>
                    <TableHead className="text-white/70">Name</TableHead>
                    <TableHead className="text-white/70">Registered Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {students.map((student) => (
                    <TableRow key={student.id} className="border-white/10">
                      <TableCell className="text-white">{student.id}</TableCell>
                      <TableCell className="text-white">{student.enrollment}</TableCell>
                      <TableCell className="text-white">{student.name}</TableCell>
                      <TableCell className="text-white">{new Date(student.created_at).toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <Users className="h-12 w-12 text-white/30 mx-auto mb-4" />
              <p className="text-white/70">No students registered yet</p>
              <p className="text-white/50 text-sm">Register students to see them here</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
